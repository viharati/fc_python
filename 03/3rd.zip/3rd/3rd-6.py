# -*- coding:utf-8 -*-

# 테스트를 위해 각 자료형 별 변수
var1 = 'abcd'
var2 = [0, 1, 2, 3]
var3 = ('a', 'b', 'c', 'd')
var4 = {'k1' : 'v1', 'k2' : 'v2'}

print len(var1)
print len(var2)
print len(var3)
print len(var4)

var5 = '100'

print int(var5)

var6 = 1000

print str(var2)
print str(var3) + "---"
print str(var4) + "---"
print str(var6) + "---"

print '-'*10

print list(var1)
print list(var2)
print list(var3)
print list(var4)

print '-'*10

print tuple(var1)
print tuple(var2)
print tuple(var3)
print tuple(var4)







