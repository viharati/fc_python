# -*- coding:utf-8 -*-

class SimpleTest():
    a = 0
    b = 0
    c = 0

simple1 = SimpleTest()

print simple1.a
print simple1.b
print simple1.c

simple1.a = 100

simple2 = SimpleTest()

print simple2.a