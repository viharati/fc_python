# -*- coding:utf-8 -*-

def send_mail(from_email, to_email, subj, cont):
    print "from:\t" + from_email
    print "to:\t" + to_email
    print "subj: " + subj
    print "Contents"
    print cont
    print "*"*10

# 보내는 메일에 사용할 내 이메일을 지정
my_email = 'alghost.lee@gmail.com'

# 보낼 사람들 정보를 만든다.
users = []
# 제목에 이름을 표기하기 위해 이름과, 이메일을 갖는 딕셔너리를 추가
users.append({'name': 'john', 'email':'john@gmail.com'})
users.append({'name': 'joy', 'email':'joy@gmail.com'})

# 같은 내용을 보내기 위해 내용을 담은 변수를 만든다.
contents = 'Thank you'
for user in users:
    # 제목에 이름을 추가하기 위해 만듬
    title = "Dear. " + user['name']
    # 이메일을 전송
    send_mail(my_email, user['email'], title, contents)




