
aaa = 100

def mysum(a, b, aaa):
    result = a+b
    return result

mysum(10, 20, aaa)
print result