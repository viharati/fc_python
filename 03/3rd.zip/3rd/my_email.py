# -*- coding:utf-8 -*-

class Email():
    from_email = ''
    to_email   = ''
    subject    = ''
    contents   = ''

    def send_mail(self):
        print "From: " + self.from_email
        print "Send to "  + self.to_email + "\n"


def get():
    pass

def set():
    pass