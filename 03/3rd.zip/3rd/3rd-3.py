# -*- coding:utf-8 -*-

# 문자열을 입력받고 문자열에 'bad'가 포함된 경우 출력하지 않고 종료
def myprint(string):
    # 'bad'가 포함된 경우 구분선('---')을 출력하지 않음
    if 'bad' in string:
        print 'Rejected'
        return
    else:
        print string

    print '-'*10

user_input = ''
while user_input != 'quit':
    user_input = raw_input('Input: ')
    # python3
    #user_input = input('Input: ')
    myprint(user_input)