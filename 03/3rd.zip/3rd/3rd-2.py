# -*- coding:utf-8 -*-

# 두 값을 더하는 함수
def num_sum(a, b):
    return a+b

# 함수를 호출하고 결과확인
res = num_sum(10, 20)
print res