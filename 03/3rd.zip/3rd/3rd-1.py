# -*- coding:utf-8 -*-

# 이름을 출력하는 함수를 만듬
def print_name():
    print "my name is \"taehwa\""


print "hello fastcampus"
res = print_name()
print_name()
print_name()
print_name()
