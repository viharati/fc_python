# -*- coding:utf-8- -*-

var1 = 'abcd'
var2 = [0, 1, 2, 3]
var3 = ('a', 'b', 'c', 'd')
var4 = {'k1' : 'v1', 'k2' : 'v2'}

# 0~9까지 리스트를 만들 때 사용(즉, 횟수반복에서 많이 사용됨)
print range(10)
# 1이상 10미만까지 리스트를 만들 때 사용
print range(1, 10)
# 1이상 10미만의 리스트를 2만큼의 간격을 가진 숫자로 만들 때 사용
print range(1, 10, 2)

print '-'*10

print max(var1)
print max(var2)
print max(var3)

print '-'*10

print min(var1)
print min(var2)
print min(var3)





