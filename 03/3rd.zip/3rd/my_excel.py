# -*- coding:utf-8 -*-

class Excel():
    excel_file = ''

    # excel파일에 저장
    def save_to_excel(self, list_data):
        for data in list_data:
            print "Save " + data + " into " + self.excel_file