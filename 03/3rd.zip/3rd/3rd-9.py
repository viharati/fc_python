# -*- coding:utf-8 -*-

class SimpleTest():
    prefix = 'Said: '
    postfix = '\n' + '-'*10

    # self 가 있지만 실제 함수 호출을 할 때는 하나의 인자값사용
    def myprint(self, string):
        # 클래스 안에 정의된 변수와 인자값을 더해서 출력
        print self.prefix + string + self.postfix

simple1 = SimpleTest()
simple1.myprint('alghost')

