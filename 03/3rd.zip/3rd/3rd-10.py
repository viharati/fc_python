# my_email 안의 모든 함수, 클래스를 가져오는 코드
from my_email import *

import my_email
m_email = my_email.Email()

from a.my_email import *


import email