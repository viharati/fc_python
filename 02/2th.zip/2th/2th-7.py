# -*- coding:utf-8 -*-

# break 구문 예제 
# break를 만나서 바로 반복문을 빠져나옴
for i in range(10):
    print i
    break
    print "!!!"

print "-"*10

# continue 구문 예제
# 해당 반복단계에서 continue 뒤 문장을
# 멈추고 반복문을 마저 수행 
for i in range(10):
    print i
    continue
    print "!!!"
