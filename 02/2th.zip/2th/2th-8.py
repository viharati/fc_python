# -*- coding: utf-8 -*-
person = {'name' : 'Taehwa', 'age' : '30', 'phone':'01012341234'}

# 반환 데이터를 확인해보기 위한 출력
print person.keys()
print person.values()
print person.items()

# keys함수를 활용하여 딕셔너리 순회
# key 값으로 딕셔너리 변수에 직접 인덱싱하여 사용
for key in person.keys():
    print 'key is ' + key
    print 'value is ' + person[key]

print "-"*10

# values함수를 활용하여 딕셔너리 순회
# key에 대해 알수가 없음
for value in person.values():
    print 'value is ' + value

print "-"*10

# items함수를 활용하여 딕셔너리 순회
# 튜플로 반환되는 items를 각각 변수로 받아 사용할 수 있음
for (key,value) in person.items():
    print 'key is ' + key
    print 'value is ' + value
