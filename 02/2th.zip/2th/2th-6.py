# -*- coding:utf-8 -*-

# while문에서 user_input을 사용하기 위해
# 미리 변수를 생성해놓아야함
# 빈 문자열로 생성
user_input = ''

# user_input이 'quit'이 아닐동안 반복
while user_input != 'quit':
    # 사용자로부터 입력을 받음
    # 입력을 받을 때, 'Input: '이라는
    # 문자열 출력 후 대기
    user_input = raw_input('Input: ')

    # 입력이 받은 후, 입력 내용을 출력
    print user_input
