# -*- coding:utf-8 -*-

# 0,1,2,3,'alghost'로 된 리스트의 항목을
# 반복문에서 하나씩 꺼내서 출력
for idx in [0,1,2,3,'alghost']:
    print idx

print '-'*10
# 위와 같은 활용는 변수를 통해서도 할 수 있음
value = ['a', 'b', 'c', 'd']
for idx in value:
    print idx

print '-'*10
# range 함수를통해서 10번 반복
for idx in range(10):
    print idx
