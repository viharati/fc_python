# -*- coding:utf-8 -*-

value = 0
value2 = 1

# 둘다 참일 경우
if value and value2:
    print "A"
# 둘중 하나가 참일 경우
elif value or value2:
    print "B"

# ---------------------------
# value 가 value2보다 큰 경우
if value > value2:
    print "a"
# value 가 value2보다 작은 경우
elif value < value2:
    print "tytyh"


value3 = ['a', 'b', 'c']

# value3에 'a'가 있는 경우
if 'a' not in value3:
    print value3
