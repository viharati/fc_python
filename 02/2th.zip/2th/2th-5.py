# -*- coding:utf-8 -*-

# value 값을 0으로 만듬
value = 0
# value가 10보다 크거나 같을때까지 반복
while value < 10:
    print value
    value = value + 1