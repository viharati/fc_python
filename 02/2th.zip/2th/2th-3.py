# -*- coding:utf-8 -*-
emails = ['a@gmail.com', 'b@gmail.com', 'c']
desc = 'For developer'
students_count = 10

# emails 리스트의 각 요소에 
# '@'가 존재하는지 확인하고, 없는 경우 'Wrong'출력
for e in emails:
    if '@' not in e:
        print 'Wrong; ' + e
    #  '@'이 있는 경우에는 이메일을 출력
    else:
        print e

# desc 변수에 'developer'가 있는 경우
# 이를 'beginner'로 변경
# !! replace 는 변경 결과를 "반환"하는 함수
if 'developer' in desc:
    desc = desc.replace('developer', 'beginner')

# students_count가 5이상인 경우 5로 변경하고 출력
if students_count >= 5:
    students_count = 5
    print "Exceed"
