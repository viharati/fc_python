# -*- coding:utf-8 -*-

# 테스트에 사용할 변수를 생성
value = "fastcampus"

# 위 value라는 이름을 가진 변수가
# "fast"라는 문자와 동일한 경우
if value == "fast":
    # "fast"라는 문자열을 출력
    print "fast"
# "campus"라는 문자와 동일한 경우
elif value == "campus":
    # "campus"라는 문자열을 출력
    print "campus"
# 그 외의 경우
else:
    # value 값을 출력
    print value

