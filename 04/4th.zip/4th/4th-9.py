#-*- coding:utf-8 -*-
from openpyxl import load_workbook

# 읽기 전용으로 데이터를 읽음
# 이때 모든 정보를 파이썬으로 가져오지 않음
wb = load_workbook('my_result.xlsx', read_only=True)
# 시트 가져오기
data = wb['Sheet']

# 한 행씩 데이터를 가져오는데 가져올 열과 행을 지정
for row in data.iter_rows(min_row=2, max_col=3, max_row=4):
# 한 행씩 데이터를 가져옴
#for row in data.iter_rows():
    # 한 행에 담긴 셀들의 값을 출력
    for cell in row:
        print cell.value