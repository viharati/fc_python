#-*- coding:utf-8 -*-

from openpyxl import load_workbook

wb = load_workbook('my_result.xlsx')
data = wb.active
# 1번째 행을 가져옴
rows = data[2]
# 1번째 행은 다수의 컬럼을 가진 리스트
for col in rows:
    # 각 컬럼의 값을 출력
    print col.value

# A번째 열을 가져옴
# TODO: 숫자로 열 접근하기
cols = data['A']
# A번째 열은 다수의 값을 가진 리스트
for row in cols:
    print row.value
