#-*- coding:utf-8 -*-

# openpyxl 라이브러리로부터 load_workbook 함수를 가져옴
from openpyxl import load_workbook

# textfile.xlsx를 가져옴
wb = load_workbook('textfile.xlsx')

# 시트 선택
sheet = wb['Sheet1']

# 해당 시트의 셀에 접근
print sheet['A1'].value
print sheet['B1'].value
print sheet['D1'].value
