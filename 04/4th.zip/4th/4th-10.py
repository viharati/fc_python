#-*- coding:utf-8 -*-
from openpyxl import load_workbook

# 논문 정보가 담긴 sample.xlsx 를 연다
wb = load_workbook('sample.xlsx')

# 데이터가 있는 시트를 가져옴
ws = wb['Sheet1']
# 원하는 논문명을 옮기기 위한 시트를 가져옴
write_ws = wb['Sheet2']

# 두번째 줄부터 내용이 있기 때문에 2부터 시작
idx = 2
while True:
    # 두번째 줄의 내용을 가졍모
    row = ws[idx]

    # 엑셀의 끝까지 도달했다면 반복문을 나간다.
    if not row[0].value:
        break

    # 0: 'A', 1: 'B', 2: 'C', 3: 'D'
    # D에 논문명이 있음
    if 'of' in row[3].value:
        # 옮기기 위한 시트에 논문명을 추가
        write_ws.append([row[3].value])

    # 다음행으로 이동하기 위해 idx를 증가
    idx = idx + 1

# 파일 저장
wb.save('result.xlsx')

