#-*- coding:utf-8 -*-

# openpyxl 라이브러리로부터 load_workbook 함수를 가져옴
from openpyxl import Workbook

# 새로운 엑셀파일 생성을 위해 빈 클래스 변수 생성
wb = Workbook()
# 시트를 생성
ws = wb.create_sheet('sheet_test')

# 셀의 데이터를 추가
ws['A1'] = 'A1-1'
ws['B1'] = 'B1-1'

# 엑셀 파일 저장
wb.save('my_result.xlsx')