#-*- coding:utf-8 -*-

# text.txt 파일을 읽기용('r')으로 가져옴
datafile = open('text.txt', 'r')

# 파일의 전체 텍스트 내용을 가져옴
data = datafile.read()

# 내용 출력
print data
# 윈도우 사용자의 경우 화면(명령프롬프트)에 맞는 인코딩으로 변경
print data.decode('utf-8').encode('euc-kr')