#-*- coding:utf-8 -*-

from openpyxl import load_workbook

wb = load_workbook('my_result.xlsx')
data = wb.active

# B2 정보를 가져온다. 
print data.cell(row=2, column=2).value
