#-*- coding:utf-8 -*-
from openpyxl import load_workbook

wb = load_workbook('my_result.xlsx')
data = wb['Sheet']

# A2, A3, B2, B3 영역을 가져옴
# 리스트의 리스트 형태로 되어있음
# [
#     [col1, col2]   # 1번째 row
#     [col1, col2]   # 2번째 row
# ]
t_data = data['A2:B3']
for row in t_data:
    for cell in row:
        print cell.value

# [
#     [row1, row2]   # 1번째 col
#     [row1, row2]   # 2번째 col
# ]
t_data = data['A:B']
for col in t_data:
    for cell in col:
        print cell.value

# [
#     [col1, col2]   # 1번째 row
#     [col1, col2]   # 2번째 row
# ]
t_data = data[2:4]
for row in t_data:
    for cell in row:
        print cell.value












