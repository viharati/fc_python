#-*- coding:utf-8 -*-

# 문자열을 입력받음
user_input = raw_input('Input: ')
# 쓰기위해 output.txt 파일을 오픈 (없을경우 새로 생성)
#datafile = open('output.txt', 'w')
datafile = open('output.txt', 'a')
# 내용을 씀
datafile.write(user_input+'\n')