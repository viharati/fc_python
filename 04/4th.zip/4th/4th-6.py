#-*- coding:utf-8 -*-

# 기존 파일에 쓰기를 실습하기 위해 load_workbook를 가져옴
from openpyxl import load_workbook

# 4th-5.py에서 생성한 파일을 연다
wb = load_workbook('my_result.xlsx')

# 맨 처음 활성화되는 시트를 가져옴
# 즉, 자동으로 생성되었던 Sheet를 가져옴
ws = wb.create_sheet('append_result')

# 헤더로 사용할 내용 한줄 추가
ws.append(['Number'])

# 내용 추가
for i in range(20):
    ws.append([i])

# 같은 파일로 저장
wb.save('my_result.xlsx')