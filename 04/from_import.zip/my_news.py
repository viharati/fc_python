# -*- coding:utf-8 -*-

class News():
    news = []

    # 뉴스를 가져오는 함수
    # 키워드를 입력받아 뉴스 제목을 가져옴
    def get_news(self, keyword):
        print "find news"
        for i in range(10):
            self.news.append("\'" + str(i) + "news. " + keyword)
        print "finished"
        return self.news
