# -*- coding:utf-8 -*-

# 각 파일에 있는 클래스를 가져옴
from testlib.my_email import Email
from my_news import News
from my_excel import Excel

# 각각 클래스 변수를 생성
m_email = Email()
m_news = News()
m_excel = Excel()

# fastcampus 키워드를 가진 뉴스를 가져옴
news_list = m_news.get_news('fastcampus')

# 이메일을 보내기 위한 정보 설정
m_email.from_email = 'alghost.lee@gmail.com'
m_email.to_email = 'yskim@fastcampus.com'
m_email.subject = 'Dear. '

# 이메일에 수집된 뉴스를 넣기 위해 내용 추가
for news in news_list:

    m_email.contents = m_email.contents + news + '\n'

# 메일 전송
m_email.send_mail()

# 저장 파일 지정후 저장
m_excel.excel_file = 'resut.xlsx'
m_excel.save_to_excel(news_list)




